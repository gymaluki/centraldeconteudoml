# Quiz — Aula gratuita Mercado Livre

Site de uma página só (HTML + CSS + JS, sem build). Tudo que foi montado está dentro do `index.html`:
as 6 telas do quiz, as animações, o confete, o aviso "Você vendeu!", a tela "Seu plano" e as logos
(embutidas no próprio arquivo).

## Como usar
- **Testar:** dê dois cliques no `index.html`.
- **Mandar pra alguém:** envie o zip inteiro; a pessoa extrai e abre o `index.html`.
- **GitHub Pages:** suba esta pasta num repositório → Settings → Pages → Branch `main` / pasta `/ (root)`.
- **Netlify / Vercel:** arraste a pasta para o painel e pronto.

## Suas fotos (opcional)
Coloque na pasta `assets/` com estes nomes exatos:
- `antes.jpg` → foto do "ANTES"
- `hoje.jpg` → foto do "HOJE"

Se o arquivo não existir, aparece só a moldura vazia.

## Pasta
```
index.html                      ← o site inteiro
assets/logo-mercadolivre.png    ← cópia da logo (já embutida no index.html)
assets/logo-shopee.png          ← cópia da logo (já embutida no index.html)
```

## Observações
- As fontes (Archivo, Inter, JetBrains Mono) vêm do Google Fonts; precisa de internet para aparecerem
  com o visual exato. Sem internet, o site usa uma fonte padrão do aparelho.
- O botão de play da tela "Seu plano" ainda não toca nenhum vídeo.
